# AI-Powered Resume Analyzer & Job Matcher

This project uses NLP to parse resumes and match them with job descriptions.